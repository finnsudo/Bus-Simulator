# 🚌 Bus Simulator (Beta)

Ein Bus-Simulationsspiel für den Browser (eine einzelne HTML-Datei, keine Abhängigkeiten).

## Spielen
`index.html` im Browser öffnen oder per GitHub Pages hosten.

## Modi
- **Karriere:** 6 Haltestellen mit Zeitdruck, Pünktlichkeitsbonus und Punktzahl
- **Sandbox:** freies Fahren ohne Zeit und ohne Game Over

## Steuerung
- Pfeiltasten / WASD: fahren
- Leertaste: Türen öffnen/schließen
- Q / E: Blinker links/rechts
- Touch-Buttons auf dem Handy

## Features
Blinker, Tag-/Nacht-Zyklus mit Scheinwerfern, Werkstatt mit Upgrades (Motor, Bremsen, Stoßfänger, Sitzplätze), gespeicherter Kontostand (localStorage).
